runtime per image [s] : 0.077
CPU[1] / GPU[0] : 0
Extra Data [1] / No Extra Data [0] : 1
